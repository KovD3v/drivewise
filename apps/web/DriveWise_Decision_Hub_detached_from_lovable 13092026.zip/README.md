# DriveWise Decision Hub

DriveWise aiuta a scegliere un'auto, una moto o uno scooter tramite un wizard conversazionale che costruisce un profilo decisionale e restituisce un ranking di veicoli con punteggio spiegato (motivazioni e compromessi), non un semplice comparatore.

## Stack

- [TanStack Start](https://tanstack.com/start) (React 19) + [TanStack Router](https://tanstack.com/router) — routing a file, SSR
- [TanStack Query](https://tanstack.com/query) per lo stato server-side
- Vite 8 + [Nitro](https://nitro.build) per il build/deploy del server
- Tailwind CSS v4, Radix UI, componenti in stile shadcn
- [Supabase](https://supabase.com) per autenticazione e persistenza (`saved_analyses`, `profiles`)
- Vitest per i test

Il progetto non dipende più da alcun preset o servizio di Lovable: `vite.config.ts` configura esplicitamente i plugin TanStack Start/Nitro/Tailwind, e il login usa `supabase.auth.signInWithOAuth` direttamente.

## Sviluppo

Richiede Node.js e [Bun](https://bun.sh) (o npm/pnpm, adattando i comandi).

```sh
bun install
bun run dev
```

Copia `.env.example` (se presente) in `.env` e imposta le variabili Supabase:

```
SUPABASE_URL=...
SUPABASE_PUBLISHABLE_KEY=...
VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...
# solo per operazioni server-side che bypassano la RLS
SUPABASE_SERVICE_ROLE_KEY=...
```

## Script

| Comando | Descrizione |
| --- | --- |
| `bun run dev` | avvia il dev server (Vite + TanStack Start) |
| `bun run build` | build di produzione (client + server via Nitro) |
| `bun run preview` | serve la build di produzione in locale |
| `bun run lint` | ESLint |
| `bun run format` | Prettier |
| `bun test` / `vitest` | scenari di accettazione del motore decisionale |

Il target di deploy di Nitro è configurabile tramite la variabile d'ambiente `NITRO_PRESET` (default: `node-server`); vedi la [lista dei preset Nitro](https://nitro.build/deploy) per Vercel, Cloudflare, Deno, ecc.

## Dati

Il catalogo veicoli (`src/data/drivewise/functional-v1/`) è un dataset funzionale statico v1 (30 veicoli). Il layer dati (`src/services/vehicleService.ts`) è scritto per essere sostituito da chiamate REST/DB senza toccare i componenti.

## Backend Supabase

Le migrazioni in `supabase/migrations/` definiscono le tabelle `saved_analyses` e `profiles` con Row Level Security per-utente. Se usi la CLI Supabase:

```sh
supabase link --project-ref <project-id>
supabase db push
```
