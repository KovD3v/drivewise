# Agent notes

This is a plain TanStack Start project (see README.md) — not connected to any
external editor or sandbox. Normal git workflow applies: no special handling
needed for force-pushes, rebases, or branch history.

A few conventions worth knowing before editing:

- Server-only code must live in a `*.server.ts` file or be marked with
  `@tanstack/react-start/server-only`. The Next.js `server-only` package is
  not used here (see `eslint.config.js`'s `no-restricted-imports` rule and
  the `importProtection` option in `vite.config.ts`, which fails the build if
  server-only code is imported from client code).
- `src/services/vehicleService.ts` is the single data-access boundary for
  vehicle data — its functions are already async so a future REST/DB backend
  can replace the local JSON dataset without touching components.
- `src/lib/decision-engine.ts` intentionally never fabricates data: every
  score/why/tradeoff is derived only from fields present in the dataset (see
  the comments in that file and in `src/lib/report-sections.ts`).
