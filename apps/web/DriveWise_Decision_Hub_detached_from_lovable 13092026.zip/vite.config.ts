// Plain TanStack Start + Vite config — no third-party preset, fully explicit
// and portable to any TanStack Start deployment target.
//
// This used to go through @lovable.dev/vite-tanstack-config, which wraps the
// same plugins below plus a set of Lovable-sandbox-only concerns (asset
// proxying, HMR bridge to the Lovable editor, forced cloudflare-module
// preset, etc.). Those are intentionally not reproduced here — this project
// no longer depends on the Lovable sandbox to build or run.
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import { nitro } from "nitro/vite";
import tailwindcss from "@tailwindcss/vite";
import viteReact from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import tsConfigPaths from "vite-tsconfig-paths";

export default defineConfig(async ({ command, mode }) => ({
  plugins: [
    tailwindcss(),
    tsConfigPaths({ projects: ["./tsconfig.json"] }),
    tanstackStart({
      // Redirect TanStack Start's server entry to src/server.ts (our SSR error wrapper).
      server: { entry: "server" },
      // Fail the build if server-only code (files under **/server/**, or the
      // Next.js `server-only` package — see eslint.config.js) leaks into the client bundle.
      importProtection: {
        behavior: "error",
        client: { files: ["**/server/**"], specifiers: ["server-only"] },
      },
    }),
    // Nitro bundles the deployable server. Only needed for `vite build`; the
    // dev server runs TanStack Start's own Vite middleware instead.
    // Defaults to a portable Node server — override with NITRO_PRESET
    // (see https://nitro.build/deploy) to target Vercel, Cloudflare, Deno, etc.
    ...(command === "build"
      ? [nitro({ preset: process.env["NITRO_PRESET"] ?? "node-server" })]
      : []),
    viteReact(),
    // TanStack Devtools panel, dev-only.
    ...(mode === "development"
      ? [
          (await import("@tanstack/devtools-vite")).devtools({
            logging: false,
            eventBusConfig: { enabled: false },
          }),
        ]
      : []),
  ],
  resolve: {
    dedupe: [
      "react",
      "react-dom",
      "react/jsx-runtime",
      "react/jsx-dev-runtime",
      "@tanstack/react-query",
    ],
  },
}));
